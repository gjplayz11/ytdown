from yt_dlp.extractor.common import InfoExtractor


class NormalPluginIE(InfoExtractor):
    pass


class _IgnoreUnderscorePluginIE(InfoExtractor):
    pass
